class Callback:
    def __init__(self):
        self.model = None
        
    def set_model(self, model):
        self.model = model 