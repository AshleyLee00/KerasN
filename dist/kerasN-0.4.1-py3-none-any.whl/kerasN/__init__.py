"""
kerasN - 순수 Python/NumPy로 구현된 간단한 딥러닝 프레임워크
"""

__version__ = '0.4.0'

from .models import Sequential
